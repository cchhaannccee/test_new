[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=13384184)
# IB9JHO Assignment 1 - Vanilla Options Pricing

# Files to work on
You should only edit:
- src/OptionPricingFunctions.c
- src/main.c
- src/option_pricing_convergence.c
- tests/benchmark_option_pricing_functions.cpp
- tests/test_exercise_price_calculator.cpp
- tests/test_option_pricing_functions.cpp

Remember to add a report.pdf 

# Submission
Submit your work by pushing to your assignment repository, downloading the zip file from github and uploading it to the course page.